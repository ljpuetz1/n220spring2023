for(let i=0;i<5;i++){
    let cirro=document.createElement('p')
    cirro.innerHTML="cirro and cumulo and nimbo and strato"

    document.body.appendChild(cirro);
}



